let colors = require("colors");
let http = require("http");
let express = require("express");
let bodyParser = require("body-parser");

let mongodb = require("mongodb")

let app = express();
app.use(express.static("./public"));
app.use(bodyParser.urlencoded({extended: false }));
app.use(bodyParser.json());

const MongoClient = mongodb.MongoClient
const uri = 'mongodb://localhost:27017';
const client = new MongoClient(uri, {useNewUrlParser: true })

let dbo = client.db("exemplo_bd");
let usuarios = dbo.collection("usuarios")

let server = http.createServer(app);
server.listen(3000);

console.log("Servidor rodando...". rainbow);

////

app.post("/cadastrar_usuario", function(req, resp) {
    var data = {  
        db_email: req.body.email, 
        db_senha: req.body.senha 
    };

    usuarios.insertOne(data, function (err) {
      if (err) {
        console.log(err);
        resp.render('resposta_usuario.ejs', {resposta: "Erro ao cadastrar usuário!"})
      }else {
        resp.render('resposta_usuario.ejs', {resposta: "Usuário cadastrado com sucesso!"})        
      };
    });
  });

  app.get("/for", function(req,res){
      let qtde = req.query.qtde;
      res.render("for.ejs", {qtde: qtde});
  })

app.post("/logar_usuario", function(req, resp) {
    var data = {  
        db_email: req.body.email, 
        db_senha: req.body.senha 
    };

    usuarios.findOne(data, function (err, result) {
      if (result == null) {
        console.log(err);
        resp.render('resposta_usuario.ejs', {resposta: "Usuário não encontrado!"})
      }else {
        resp.render('resposta_usuario.ejs', {resposta: "Login realizado com sucesso!"})        
      };
    });
  });

app.get("/logar_usuario", function(req, res){
  let email = req.query.email;
  let senha = req.query.senha;

  let data = {db_email: email, db_senha: senha}

  usuarios.find(data).toArray(function(err, itens){
    if(err){
      console.log(err);
      res.render('resposta_usuario.ejs', {resposta: "Erro ao buscar usuário!"})
    } else if (itens.length == 0){
      res.render('resposta_usuario.ejs', {resposta: "Usuário/Senha não encontrado!"})
    } else{
      res.render('resposta_usuario.ejs', {resposta: "Usuário logado com sucesso!"})
    }
  })
})

app.post("/editar_usuario", function(req, res){
  let email = req.body.email;
  let senha = req.body.senha;
  let nova_senha = req.body.nova_senha;

  let data = {db_email: email, db_senha: senha};
  let newdata = {$set: {db_senha: nova_senha}};

  const result = usuarios.updateOne(data, newdata);
  console.log(result);

  if(result.matchedCount == 0) {
    res.render('resposta_usuario.ejs', {resposta: "Usuário/Senha não encontrado!"})
  } else {
    res.render('resposta_usuario.ejs', {resposta: "Usuário/Senha atualizado com sucesso!"})
  }
}) 

app.get("/remover_usuario", function(req, res){
  let email = req.query.email;
  let senha = req.query.senha;
  let data = {db_email: email, db_senha: senha};

  const result = usuarios.deleteOne(data);
  console.log(result);

  if(result.deletedCount == 0){
    res.render('resposta_usuario.ejs', {resposta: "Usuário/Senha não encontrado!"})
  } else {
    res.render('resposta_usuario.ejs', {resposta: "Usuário removido com sucesso!"})
  }
})